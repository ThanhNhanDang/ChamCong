# Thiết lập ZKTeco Local Controller tự động chạy trên Mini PC Windows

## 1. Khuyến nghị triển khai

Source Controller hiện là ứng dụng Windows Forms:

```text
RTEvents.exe
.NET Framework 4.8
Platform target: x86
Có sử dụng zkemkeeper COM SDK
```

Vì đây là ứng dụng có UI và dùng COM SDK, cách ổn định nhất là:

```text
Windows auto login user kỹ thuật
→ Task Scheduler chạy RTEvents.exe sau khi user đăng nhập
```

Không khuyến nghị chạy ngay dạng Windows Service nếu chưa tách phần service/headless, vì Windows Service thường không có interactive desktop và có thể gặp lỗi với WinForms/COM SDK.

---

## 2. Chuẩn bị thư mục triển khai

Tạo thư mục:

```text
C:\ZKTecoController
```

Copy toàn bộ file build output vào thư mục này, tối thiểu gồm:

```text
RTEvents.exe
RTEvents.exe.config
Interop.zkemkeeper.dll
AxInterop.zkemkeeper.dll
zkemkeeper.dll
các DLL dependency khác
```

Khuyến nghị copy nguyên thư mục:

```text
bin\Release
```

hoặc:

```text
bin\Debug
```

sau khi build thành công.

---

## 3. Kiểm tra file config

Mở:

```text
C:\ZKTecoController\RTEvents.exe.config
```

Kiểm tra các key quan trọng:

```xml
<add key="ControllerId" value="controller-01" />
<add key="ManualOdooBaseUrl" value="http://192.168.1.244:9000" />
<add key="ControllerApiPort" value="6000" />
<add key="AgentApiKey" value="dev-secret-key" />
```

Nếu Odoo gọi API Agent tại:

```text
http://192.168.1.10:6000
```

thì mini PC cần cố định IP là:

```text
192.168.1.10
```

---

## 4. Register ZKTeco SDK

Nếu dùng SDK 32-bit, chạy CMD bằng quyền Administrator:

```bat
C:\Windows\SysWOW64\regsvr32.exe C:\ZKTecoController\zkemkeeper.dll
```

Nếu dùng SDK 64-bit:

```bat
C:\Windows\System32\regsvr32.exe C:\ZKTecoController\zkemkeeper.dll
```

Với source hiện tại build x86, thường dùng lệnh SysWOW64.

---

## 5. Cài auto start bằng Task Scheduler

Copy các file script này vào mini PC, ví dụ:

```text
C:\ZKTecoController\scripts
```

Mở PowerShell bằng quyền Administrator và chạy:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
cd C:\ZKTecoController\scripts
.\install-autostart-task.ps1 -AppDir "C:\ZKTecoController" -TaskName "ZKTeco Local Controller" -ApiPort 6000
```

Script sẽ tự làm:

```text
1. Tạo Scheduled Task
2. Chạy RTEvents.exe khi user đăng nhập
3. Delay 30 giây sau login
4. Run with highest privileges
5. Add URL ACL cho http://+:6000/
6. Add firewall rule TCP 6000
```

---

## 6. Test chạy thử

Chạy task thủ công:

```powershell
Start-ScheduledTask -TaskName "ZKTeco Local Controller"
```

Kiểm tra process:

```powershell
Get-Process RTEvents -ErrorAction SilentlyContinue
```

Kiểm tra API health:

```powershell
Invoke-RestMethod http://127.0.0.1:6000/health
```

Hoặc mở browser:

```text
http://127.0.0.1:6000/health
```

Kỳ vọng:

```json
{
  "success": true,
  "message": "ZKTeco Local API is running."
}
```

---

## 7. Thiết lập Windows tự login

Vì Task Scheduler đang chạy ở chế độ At Logon, mini PC nên được cấu hình auto login user kỹ thuật.

Cách phổ biến:

```text
Win + R
→ netplwiz
→ chọn user kỹ thuật
→ bỏ tick "Users must enter a user name and password to use this computer"
→ nhập password
→ restart để test
```

Lưu ý bảo mật:

```text
Mini PC nên đặt trong mạng nội bộ
Không dùng user admin domain quan trọng
Nên đặt password riêng cho user chạy Controller
```

---

## 8. Cố định IP cho mini PC

Trên router hoặc Windows, cố định IP mini PC, ví dụ:

```text
192.168.1.10
```

Odoo sẽ gọi Agent theo URL:

```text
http://192.168.1.10:6000
```

Nếu IP thay đổi, Odoo sẽ không gọi được Agent.

---

## 9. Tắt Sleep / Hibernate

Trên mini PC, nên tắt sleep:

```powershell
powercfg /change standby-timeout-ac 0
powercfg /change hibernate-timeout-ac 0
powercfg /hibernate off
```

Nếu máy sleep, Agent sẽ mất kết nối với thiết bị và Odoo không gọi được API.

---

## 10. Kiểm tra sau khi restart

Sau khi restart mini PC:

```text
1. Windows tự login
2. Sau khoảng 30 giây, RTEvents.exe tự mở
3. Truy cập được http://127.0.0.1:6000/health
4. Odoo Connect Device thành công
5. Odoo Sync All Users thành công
```

---

## 11. Gỡ auto start

Chạy PowerShell Administrator:

```powershell
cd C:\ZKTecoController\scripts
.\uninstall-autostart-task.ps1 -TaskName "ZKTeco Local Controller" -ApiPort 6000
```

---

## 12. Khi nào nên chuyển sang Windows Service?

Chỉ nên chuyển sang Windows Service khi đã tách Controller thành dạng headless, không phụ thuộc WinForms UI.

Nếu vẫn muốn chạy bằng service, có thể dùng NSSM, nhưng cần test kỹ:

```text
- zkemkeeper COM có hoạt động dưới service account không
- HttpListener có start được không
- App có bị treo vì UI không hiển thị không
- Log có ghi được không
```

Với source hiện tại, khuyến nghị chính vẫn là:

```text
Task Scheduler + Auto Login
```
