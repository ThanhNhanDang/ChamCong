param(
    [string]$TaskName = "ZKTeco Local Controller",
    [int]$ApiPort = 6000
)

$ErrorActionPreference = "Continue"

Write-Host "=== ZKTeco Local Controller - Uninstall Auto Start Task ==="

$existingTask = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
if ($existingTask) {
    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
    Write-Host "Removed scheduled task: $TaskName"
} else {
    Write-Host "Scheduled task not found: $TaskName"
}

try {
    netsh http delete urlacl url="http://+:$ApiPort/" | Out-Null
    Write-Host "Removed URL ACL: http://+:$ApiPort/"
} catch {
    Write-Host "URL ACL not found or cannot remove."
}

try {
    $rule = Get-NetFirewallRule -DisplayName "ZKTeco Local Controller API $ApiPort" -ErrorAction SilentlyContinue
    if ($rule) {
        Remove-NetFirewallRule -DisplayName "ZKTeco Local Controller API $ApiPort"
        Write-Host "Removed firewall rule for port $ApiPort"
    }
} catch {
    Write-Host "Cannot remove firewall rule automatically."
}
