@echo off
setlocal

set APP_DIR=C:\ZKTecoController
set TASK_NAME=ZKTeco Local Controller
set API_PORT=6000

echo Installing auto start for ZKTeco Local Controller...
powershell -ExecutionPolicy Bypass -File "%~dp0install-autostart-task.ps1" -AppDir "%APP_DIR%" -TaskName "%TASK_NAME%" -ApiPort %API_PORT%

pause
