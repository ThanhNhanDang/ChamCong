@echo off
set APP_DIR=C:\ZKTecoController
set EXE=RTEvents.exe

cd /d "%APP_DIR%"
start "" "%APP_DIR%\%EXE%"
