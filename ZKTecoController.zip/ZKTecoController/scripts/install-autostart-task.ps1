param(
    [string]$AppDir = "C:\ZKTecoController",
    [string]$ExeName = "RTEvents.exe",
    [string]$TaskName = "ZKTeco Local Controller",
    [int]$ApiPort = 6000
)

$ErrorActionPreference = "Stop"

Write-Host "=== ZKTeco Local Controller - Install Auto Start Task ==="

$exePath = Join-Path $AppDir $ExeName

if (!(Test-Path $exePath)) {
    Write-Host "ERROR: Cannot find exe file:"
    Write-Host "  $exePath"
    Write-Host ""
    Write-Host "Please copy the published/build output folder to $AppDir first."
    exit 1
}

# Create logs folder if not exists
$logsDir = Join-Path $AppDir "logs"
if (!(Test-Path $logsDir)) {
    New-Item -ItemType Directory -Path $logsDir | Out-Null
}

# Allow HttpListener URL ACL
# This is required if the app listens on http://+:6000/
Write-Host "Adding URL ACL for http://+:$ApiPort/ ..."
try {
    netsh http add urlacl url="http://+:$ApiPort/" user="Everyone" | Out-Null
} catch {
    Write-Host "URL ACL may already exist. Continue..."
}

# Open Windows Firewall inbound port
Write-Host "Adding firewall rule for TCP port $ApiPort ..."
try {
    if (-not (Get-NetFirewallRule -DisplayName "ZKTeco Local Controller API $ApiPort" -ErrorAction SilentlyContinue)) {
        New-NetFirewallRule `
            -DisplayName "ZKTeco Local Controller API $ApiPort" `
            -Direction Inbound `
            -Protocol TCP `
            -LocalPort $ApiPort `
            -Action Allow | Out-Null
    }
} catch {
    Write-Host "Cannot create firewall rule automatically. Please create it manually if needed."
}

# Remove old task if exists
$existingTask = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
if ($existingTask) {
    Write-Host "Removing existing scheduled task: $TaskName"
    Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
}

# Create scheduled task at user logon
# WinForms app needs interactive desktop, so AtLogOn is recommended.
$action = New-ScheduledTaskAction `
    -Execute $exePath `
    -WorkingDirectory $AppDir

$trigger = New-ScheduledTaskTrigger -AtLogOn
$trigger.Delay = "PT30S"

$principal = New-ScheduledTaskPrincipal `
    -UserId "$env:USERDOMAIN\$env:USERNAME" `
    -LogonType Interactive `
    -RunLevel Highest

$settings = New-ScheduledTaskSettingsSet `
    -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries `
    -StartWhenAvailable `
    -MultipleInstances IgnoreNew `
    -ExecutionTimeLimit (New-TimeSpan -Days 0)

Register-ScheduledTask `
    -TaskName $TaskName `
    -Action $action `
    -Trigger $trigger `
    -Principal $principal `
    -Settings $settings | Out-Null

Write-Host ""
Write-Host "DONE. Scheduled task created:"
Write-Host "  Task Name : $TaskName"
Write-Host "  Exe       : $exePath"
Write-Host "  Start     : At user logon, delay 30 seconds"
Write-Host ""
Write-Host "You can test now with:"
Write-Host "  Start-ScheduledTask -TaskName `"$TaskName`""
Write-Host ""
Write-Host "Check API:"
Write-Host "  http://127.0.0.1:$ApiPort/health"
